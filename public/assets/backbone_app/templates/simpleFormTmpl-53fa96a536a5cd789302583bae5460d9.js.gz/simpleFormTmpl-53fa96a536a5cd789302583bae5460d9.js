(function() {
  this.JST || (this.JST = {});
  this.JST["backbone_app/templates/simpleFormTmpl"] = function(obj){var __p=[],print=function(){__p.push.apply(__p,arguments);};with(obj||{}){__p.push('<div class="buttons">\n    <button class="btn btn-cancel">',  I18n.t("actions.cancel") ,'</button>\n    <button class="btn btn-primary btn-submit">',  I18n.t("actions.save") ,'</button>\n</div>\n');}return __p.join('');};
}).call(this);
