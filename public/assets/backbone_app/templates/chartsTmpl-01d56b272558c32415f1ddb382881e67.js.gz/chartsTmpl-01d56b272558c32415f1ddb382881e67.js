(function() {
  this.JST || (this.JST = {});
  this.JST["backbone_app/templates/chartsTmpl"] = function(obj){var __p=[],print=function(){__p.push.apply(__p,arguments);};with(obj||{}){__p.push('<div></div>\n');}return __p.join('');};
}).call(this);
