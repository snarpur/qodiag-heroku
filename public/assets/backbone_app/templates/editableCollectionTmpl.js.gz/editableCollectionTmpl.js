(function() {
  this.JST || (this.JST = {});
  this.JST["backbone_app/templates/editableCollectionTmpl"] = function(obj){var __p=[],print=function(){__p.push.apply(__p,arguments);};with(obj||{}){__p.push('<h1>',  I18n.t("terms.parents") ,'</h1>\n<ul class="reset"></ul>\n');}return __p.join('');};
}).call(this);
