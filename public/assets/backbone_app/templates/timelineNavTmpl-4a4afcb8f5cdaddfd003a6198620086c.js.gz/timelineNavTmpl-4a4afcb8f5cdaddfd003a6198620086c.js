(function() {
  this.JST || (this.JST = {});
  this.JST["backbone_app/templates/timelineNavTmpl"] = function(obj){var __p=[],print=function(){__p.push.apply(__p,arguments);};with(obj||{}){__p.push('<ul class="reset">\n  <li><span class="icon-big-next"></span></li>\n  <li><span class="icon-big-prev"></span></li>\n</ul>\n');}return __p.join('');};
}).call(this);
