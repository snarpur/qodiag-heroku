(function() {
  this.JST || (this.JST = {});
  this.JST["backbone_app/templates/lineChartsTmpl"] = function(obj){var __p=[],print=function(){__p.push.apply(__p,arguments);};with(obj||{}){__p.push('<div id="', chart.renderTo,'"class="chart">\n\n</div>\n');}return __p.join('');};
}).call(this);
