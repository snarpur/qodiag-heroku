(function() {
  this.JST || (this.JST = {});
  this.JST["backbone_app/templates/multistepFormTmpl"] = function(obj){var __p=[],print=function(){__p.push.apply(__p,arguments);};with(obj||{}){__p.push('<div id="wizard-fields" class="wizard-fields"></div>\n<button class="btn btn-primary submit-btn">',  I18n.t("actions.save") ,'</button>\n');}return __p.join('');};
}).call(this);
