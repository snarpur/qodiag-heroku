(function() {
  this.JST || (this.JST = {});
  this.JST["backbone_app/templates/surveyMenuItemTmpl"] = function(obj){var __p=[],print=function(){__p.push.apply(__p,arguments);};with(obj||{}){__p.push('<a data-toggle="dropdown" data-target="#">', I18n.t("surveys."+access_code+".name"),'</a>\n\n');}return __p.join('');};
}).call(this);
