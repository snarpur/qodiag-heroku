(function() {
  this.JST || (this.JST = {});
  this.JST["backbone_app/templates/filtersSelectItemTmpl"] = function(obj){var __p=[],print=function(){__p.push.apply(__p,arguments);};with(obj||{}){__p.push('');}return __p.join('');};
}).call(this);
