(function() {
  this.JST || (this.JST = {});
  this.JST["backbone_app/templates/submitButton"] = function(obj){var __p=[],print=function(){__p.push.apply(__p,arguments);};with(obj||{}){__p.push('<button class="btn btn-primary btn-submit">',  I18n.t("actions.save") ,'</button>\n');}return __p.join('');};
}).call(this);
