(function() {
  this.JST || (this.JST = {});
  this.JST["backbone_app/templates/patientInformationTmpl"] = function(obj){var __p=[],print=function(){__p.push.apply(__p,arguments);};with(obj||{}){__p.push('<div class="subject">\n    <div class="avatar"></div>\n    <div class="information"></div>\n</div>\n<hr class="fullbreak" />\n<div class="parents"></div>\n</div>\n');}return __p.join('');};
}).call(this);
