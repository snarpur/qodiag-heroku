(function() {
  this.JST || (this.JST = {});
  this.JST["backbone_app/templates/filterOptionItemTmpl"] = function(obj){var __p=[],print=function(){__p.push.apply(__p,arguments);};with(obj||{}){__p.push('',  name ,'\n');}return __p.join('');};
}).call(this);
