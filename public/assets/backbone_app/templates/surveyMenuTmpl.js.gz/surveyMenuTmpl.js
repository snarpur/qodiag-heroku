(function() {
  this.JST || (this.JST = {});
  this.JST["backbone_app/templates/surveyMenuTmpl"] = function(obj){var __p=[],print=function(){__p.push.apply(__p,arguments);};with(obj||{}){__p.push('<button class="btn btn-mini dropdown-toggle" data-toggle="dropdown">\n  ',  I18n.t("terms.lists") ,'\n  <span class="caret"></span>\n</button>\n<a href="#" class="popover-target" data-placement="left" data-content="Veldu lista til að senda beiðni" data-title="Engar mælingar">&nbsp;</a>\n<ul class="dropdown-menu pull-right"></ul>\n');}return __p.join('');};
}).call(this);
