(function() {
  this.JST || (this.JST = {});
  this.JST["backbone_app/templates/useragentDetectionTmpl"] = function(obj){var __p=[],print=function(){__p.push.apply(__p,arguments);};with(obj||{}){__p.push('<div>\n\t<p>',  version ,'</p>\n</div>\n');}return __p.join('');};
}).call(this);
