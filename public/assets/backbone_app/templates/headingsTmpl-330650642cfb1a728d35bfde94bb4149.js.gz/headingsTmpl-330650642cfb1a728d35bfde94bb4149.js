(function() {
  this.JST || (this.JST = {});
  this.JST["backbone_app/templates/headingsTmpl"] = function(obj){var __p=[],print=function(){__p.push.apply(__p,arguments);};with(obj||{}){__p.push('');  var lineName = name == "" ? "client_registration" : name ;; __p.push('\n<p>', I18n.t("surveys."+name+".name"),'</p>\n<span class="new-item icon-tiny-add"></span>\n');}return __p.join('');};
}).call(this);
