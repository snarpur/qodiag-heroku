(function() {
  this.JST || (this.JST = {});
  this.JST["backbone_app/templates/headingsListTmpl"] = function(obj){var __p=[],print=function(){__p.push.apply(__p,arguments);};with(obj||{}){__p.push('<ul class="reset"></ul>\n');}return __p.join('');};
}).call(this);
