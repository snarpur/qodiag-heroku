(function(){Array.prototype.insertAt=function(a,b){this.splice(a,0,b);return this}}).call(this);
