(function() {
  toastr.options = {
    debug: false,
    positionClass: "toast-top-full-width",
    onclick: null,
    fadeIn: 300,
    fadeOut: 1000,
    timeOut: 5000,
    extendedTimeOut: 1000
  };

}).call(this);
