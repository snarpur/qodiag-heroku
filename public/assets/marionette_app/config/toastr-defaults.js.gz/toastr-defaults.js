(function(){toastr.options={debug:!1,positionClass:"toast-top-full-width",onclick:null,fadeIn:300,fadeOut:1E3,timeOut:5E3,extendedTimeOut:1E3}}).call(this);
